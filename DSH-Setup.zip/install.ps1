# DSH custom environment installer (D-drive only, C drive untouched)
$ErrorActionPreference = 'Stop'
$src = $PSScriptRoot
Write-Host ''
Write-Host '==================================================' -ForegroundColor Cyan
Write-Host '   DeepSeek Harness Custom Environment Setup (D only)' -ForegroundColor Cyan
Write-Host '==================================================' -ForegroundColor Cyan
Write-Host ''

$base = 'D:\deepskhaness'
New-Item -ItemType Directory -Force $base | Out-Null
New-Item -ItemType Directory -Force (Join-Path $base 'plugins\scripts') | Out-Null
New-Item -ItemType Directory -Force (Join-Path $base 'uploads') | Out-Null
Write-Host '[1/4] Workspace: ' $base -ForegroundColor Green

Copy-Item (Join-Path $src 'plugins\*') (Join-Path $base 'plugins\') -Recurse -Force -ErrorAction SilentlyContinue
Write-Host '[2/4] Plugin archives (7 plugins + scripts) copied' -ForegroundColor Green

Copy-Item (Join-Path $src 'uploads\*') (Join-Path $base 'uploads\') -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force (Join-Path $base 'bot') | Out-Null
Copy-Item (Join-Path $src 'bot\*') (Join-Path $base 'bot\') -Recurse -Force -ErrorAction SilentlyContinue
Write-Host '[3/4] Uploads and bot scripts in place' -ForegroundColor Green

$extra = Join-Path $base '_extra'
New-Item -ItemType Directory -Force $extra | Out-Null
Remove-Item (Join-Path $extra 'skills') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $extra 'cordis-auto-preset') -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item (Join-Path $src 'skills') (Join-Path $extra 'skills') -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item (Join-Path $src 'cordis-auto-preset') (Join-Path $extra 'cordis-auto-preset') -Recurse -Force -ErrorAction SilentlyContinue
Write-Host '[4/4] Skills/preset staged at ' $extra ' (C drive untouched)' -ForegroundColor Green

Write-Host ''
Write-Host 'D-drive install complete!' -ForegroundColor Green
Write-Host ''
Write-Host 'Optional (auto-restore on next session, writes to C:\Users\...):' -ForegroundColor Yellow
Write-Host ('  robocopy "' + (Join-Path $extra 'skills') + '" "%USERPROFILE%\.agents\skills" /E') -ForegroundColor Yellow
Write-Host ('  robocopy "' + (Join-Path $extra 'cordis-auto-preset') + '" "%USERPROFILE%\.dsh\.agent-presets\cordis-auto" /E') -ForegroundColor Yellow
Write-Host ''
Write-Host 'Then: start DSH, new session, pick "cordis-auto" preset, send any message.' -ForegroundColor Yellow
Write-Host ''
Start-Sleep -Seconds 4
