# DSH 定制环境一键安装脚本（纯 D 盘模式：不写 C 盘）
# 安装内容：插件存档 / 上传文件 / 投递脚本 到 D:\deepskhaness
# 技能与预设：只复制到 D:\deepskhaness\_extra\ 供手动安装（可选，不碰 C 盘）
$ErrorActionPreference = 'Stop'
$src = $PSScriptRoot
Write-Host ''
Write-Host '==================================================' -ForegroundColor Cyan
Write-Host '   DeepSeek Harness 定制环境安装程序（纯 D 盘）' -ForegroundColor Cyan
Write-Host '==================================================' -ForegroundColor Cyan
Write-Host ''

# 1. 工作区目录
$base = 'D:\deepskhaness'
New-Item -ItemType Directory -Force $base | Out-Null
New-Item -ItemType Directory -Force "$base\plugins\scripts" | Out-Null
New-Item -ItemType Directory -Force "$base\uploads" | Out-Null
Write-Host "[1/4] 工作区目录：$base" -ForegroundColor Green

# 2. 插件存档（含 docx 脚本）
Copy-Item "$src\plugins\*" "$base\plugins\" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "[2/4] 插件存档（7 个插件 + scripts）已复制" -ForegroundColor Green

# 3. 上传文件 / 投递脚本
Copy-Item "$src\uploads\*" "$base\uploads\" -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force "$base\bot" | Out-Null
Copy-Item "$src\bot\*" "$base\bot\" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "[3/4] 上传文件与投递脚本已就位" -ForegroundColor Green

# 4. 技能与预设 → 只留到 D 盘 extra 目录（不写 C 盘）
$extra = "$base\_extra"
New-Item -ItemType Directory -Force $extra | Out-Null
Copy-Item "$src\skills" "$extra\skills" -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item "$src\cordis-auto-preset" "$extra\cordis-auto-preset" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "[4/4] 技能/预设已备好：$extra（未写 C 盘）" -ForegroundColor Green

Write-Host ''
Write-Host 'D 盘安装完成！' -ForegroundColor Green
Write-Host ''
Write-Host '如需「自动恢复插件」功能（可选，会写 C 盘用户目录）：' -ForegroundColor Yellow
Write-Host "  robocopy `"$extra\skills`" `"%USERPROFILE%\.agents\skills`" /E" -ForegroundColor Yellow
Write-Host "  robocopy `"$extra\cordis-auto-preset`" `"%USERPROFILE%\.dsh\.agent-presets\cordis-auto`" /E" -ForegroundColor Yellow
Write-Host ''
Write-Host '然后：启动 DSH → 新会话选「创造模式·自动恢复」→ 发任意消息自动重建插件。' -ForegroundColor Yellow
Write-Host ''
Start-Sleep -Seconds 4
