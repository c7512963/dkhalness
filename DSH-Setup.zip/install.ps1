# DSH custom environment installer (D-drive only, C drive untouched)
$ErrorActionPreference = 'Stop'
$src = $PSScriptRoot
Write-Host ''
Write-Host '==================================================' -ForegroundColor Cyan
Write-Host '   DeepSeek Harness Custom Environment Setup (D only)' -ForegroundColor Cyan
Write-Host '==================================================' -ForegroundColor Cyan
Write-Host ''

$base = 'D:\deepskhaness'
New-Item -ItemType Directory -Force $base | Out-Null
New-Item -ItemType Directory -Force (Join-Path $base 'plugins\scripts') | Out-Null
New-Item -ItemType Directory -Force (Join-Path $base 'uploads') | Out-Null
Write-Host '[1/4] Workspace: ' $base -ForegroundColor Green

Copy-Item (Join-Path $src 'plugins\*') (Join-Path $base 'plugins\') -Recurse -Force -ErrorAction SilentlyContinue
Write-Host '[2/4] Plugin archives (7 plugins + scripts) copied' -ForegroundColor Green

Copy-Item (Join-Path $src 'uploads\*') (Join-Path $base 'uploads\') -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force (Join-Path $base 'bot') | Out-Null
Copy-Item (Join-Path $src 'bot\*') (Join-Path $base 'bot\') -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item (Join-Path $src 'start-dsh.bat') (Join-Path $base 'start-dsh.bat') -Force -ErrorAction SilentlyContinue
Copy-Item (Join-Path $src 'dsh-app.ico') (Join-Path $base 'dsh-app.ico') -Force -ErrorAction SilentlyContinue
Write-Host '[3/4] Uploads and bot scripts in place' -ForegroundColor Green

$extra = Join-Path $base '_extra'
New-Item -ItemType Directory -Force $extra | Out-Null
Remove-Item (Join-Path $extra 'skills') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $extra 'cordis-auto-preset') -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item (Join-Path $src 'skills') (Join-Path $extra 'skills') -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item (Join-Path $src 'cordis-auto-preset') (Join-Path $extra 'cordis-auto-preset') -Recurse -Force -ErrorAction SilentlyContinue
Write-Host '[4/4] Skills/preset staged at ' $extra ' (C drive untouched)' -ForegroundColor Green

Write-Host ''
Write-Host 'D-drive install complete!' -ForegroundColor Green
Write-Host ''

# Desktop shortcut to the standalone app window (optional; data stays on D:)
try {
  $desktop = [Environment]::GetFolderPath('Desktop')
  $ws = New-Object -ComObject WScript.Shell
  $lnk = $ws.CreateShortcut((Join-Path $desktop 'DeepSeek Harness.lnk'))
  $lnk.TargetPath = (Join-Path $base 'start-dsh.bat')
  $lnk.WorkingDirectory = $base
  $lnk.Description = 'DeepSeek Harness - AI assistant app'
  if (Test-Path (Join-Path $base 'dsh-app.ico')) { $lnk.IconLocation = (Join-Path $base 'dsh-app.ico') + ',0' }
  $lnk.Save()
  Write-Host 'Desktop shortcut created (double-click to open the app window)' -ForegroundColor Green
} catch {
  Write-Host 'Desktop shortcut skipped (non-interactive session)' -ForegroundColor Yellow
}

Write-Host ''
Write-Host 'Optional (auto-restore on next session, writes to C:\Users\...):' -ForegroundColor Yellow
Write-Host ('  robocopy "' + (Join-Path $extra 'skills') + '" "%USERPROFILE%\.agents\skills" /E') -ForegroundColor Yellow
Write-Host ('  robocopy "' + (Join-Path $extra 'cordis-auto-preset') + '" "%USERPROFILE%\.dsh\.agent-presets\cordis-auto" /E') -ForegroundColor Yellow
Write-Host ''
Write-Host 'Then: start DSH, new session, pick "cordis-auto" preset, send any message.' -ForegroundColor Yellow
Write-Host ''
Start-Sleep -Seconds 4
